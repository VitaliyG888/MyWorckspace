import { lazy, Suspense, useMemo } from "react";
import {
  BaseField,
  Field,
  FieldTransforms,
  Fields,
  RichtextField,
} from "../../../types";
import { RichTextRenderFallback } from "../components/RenderFallback";
import { mapDeep } from "./mapDeep";

const RichTextRender = lazy(() =>
  import("../components/Render").then((m) => ({
    default: m.RichTextRender,
  }))
);

type RichtextPath = {
  path: string[];
  field: RichtextField;
};

export function useRichtextProps(
  fields:
    | Fields<any, {}>
    | Fields<any, { type: string } & BaseField>
    | undefined,
  props: {
    [x: string]: any;
  },
  fieldTransforms?: FieldTransforms
) {
  const findAllRichtextKeys = (
    fields:
      | Fields<any, {}>
      | Fields<any, { type: string } & BaseField>
      | undefined,
    path: string[] = []
  ): RichtextPath[] => {
    if (!fields) return [];

    const result: RichtextPath[] = [];

    for (const [key, field] of Object.entries(fields)) {
      // A user transform for this field type replaces the whole value.
      // So we don't need to look for richtext fields inside it.
      // Users might be transforming richtext fields into something else, or
      // it might be a completely different structure (ReactNode, string, number, etc.) and we can't recurse on it.
      if (fieldTransforms?.[field.type as Field["type"]]) {
        continue;
      }

      const currentPath = [...path, key];

      if (field.type === "richtext") {
        result.push({
          path: currentPath,
          field: field as RichtextField,
        });
      }

      if (field.type === "array" && "arrayFields" in field) {
        result.push(...findAllRichtextKeys(field.arrayFields, currentPath));
      }

      if (field.type === "object" && "objectFields" in field) {
        result.push(...findAllRichtextKeys(field.objectFields, currentPath));
      }
    }

    return result;
  };

  const richtextKeys = useMemo(
    () => findAllRichtextKeys(fields),
    [fields, fieldTransforms]
  );

  const richtextProps = useMemo(() => {
    if (!richtextKeys?.length) return {};

    let result = { ...props };

    for (const { path, field } of richtextKeys) {
      result = mapDeep(result, path, (content) => (
        <Suspense
          // Deterministic key to avoid hydration mismatch. No array index needed
          // because mapDeep places each Suspense in a separate array object, not as siblings.
          key={path.join(".")}
          fallback={<RichTextRenderFallback content={content} />}
        >
          <RichTextRender content={content} field={field} />
        </Suspense>
      ));
    }

    return result;
  }, [richtextKeys, props, fields]);

  return richtextProps;
}
