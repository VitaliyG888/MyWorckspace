import {
  PropsWithChildren,
  ReactNode,
  createContext,
  useCallback,
  useMemo,
} from "react";
import type { Draggable } from "@dnd-kit/dom";
import { useAppStore } from "../../store";
import { createStore, StoreApi } from "zustand";
import { Virtualizer } from "@tanstack/react-virtual";

export type PathData = Record<string, { path: string[]; label: string }>;

export type DropZoneContext = {
  areaId?: string;
  zoneCompound?: string;
  index?: number;
  registerZone?: (zoneCompound: string) => void;
  unregisterZone?: (zoneCompound: string) => void;
  mode?: "edit" | "render";
  depth: number;
  registerLocalZone?: (zone: string, active: boolean) => void; // A zone as it pertains to the current area
  unregisterLocalZone?: (zone: string) => void;
} | null;

export const dropZoneContext = createContext<DropZoneContext>(null);

export type Preview = {
  componentType: string;
  index: number;
  zone: string;
  props: Record<string, any>;
  type: "insert" | "move";
  element: Element | undefined;
  /**
   * Render a thin line at the insertion point instead of the full item,
   * preventing layout shift.
   */
  linePlaceholder?: boolean;
  /**
   * Pins the dragged item at its last previewed position in its original
   * zone while a line placeholder shows in another zone, preventing the
   * original zone from shifting back. Ignored when committing the drag.
   */
  ghost?: boolean;
} | null;

export type RootVirtualizerHandle = {
  resolveIndex: (targetId: string) => number;
  virtualizer: Virtualizer<any, any>;
};

export type ZoneStore = {
  zoneDepthIndex: Record<string, boolean>;
  areaDepthIndex: Record<string, boolean>;
  nextZoneDepthIndex: Record<string, boolean>;
  nextAreaDepthIndex: Record<string, boolean>;
  enabledIndex: Record<string, boolean>;
  previewIndex: Record<string, Preview>;
  draggedItem?: Draggable | null;
  draggingFromHandle: boolean;
  /**
   * True while the current drag renders a static placeholder (i.e. a line placeholder).
   */
  staticDrag: boolean;
  hoveringComponent: string | null;
  registerRootVirtualizer: (
    zoneCompound: string,
    handle: RootVirtualizerHandle
  ) => void;
  unregisterRootVirtualizer: (zoneCompound: string) => void;
  scrollToComponent: (id: string) => void;
};

export const ZoneStoreContext = createContext<StoreApi<ZoneStore>>(
  createStore(() => ({
    zoneDepthIndex: {},
    nextZoneDepthIndex: {},
    areaDepthIndex: {},
    nextAreaDepthIndex: {},
    draggedItem: null,
    previewIndex: {},
    enabledIndex: {},
    hoveringComponent: null,
    draggingFromHandle: false,
    staticDrag: false,
    registerRootVirtualizer: () => {},
    unregisterRootVirtualizer: () => {},
    scrollToComponent: () => false,
  }))
);

export const ZoneStoreProvider = ({
  children,
  store,
}: PropsWithChildren<{ store: StoreApi<ZoneStore> }>) => {
  return (
    <ZoneStoreContext.Provider value={store}>
      {children}
    </ZoneStoreContext.Provider>
  );
};

export const DropZoneProvider = ({
  children,
  value,
}: {
  children: ReactNode;
  value: DropZoneContext;
}) => {
  const dispatch = useAppStore((s) => s.dispatch);

  const registerZone = useCallback(
    (zoneCompound: string) => {
      dispatch({
        type: "registerZone",
        zone: zoneCompound,
      });
    },
    [dispatch]
  );

  const memoValue = useMemo(
    () =>
      ({
        registerZone,
        ...value,
      } as DropZoneContext),
    [value]
  );

  return (
    <>
      {memoValue && (
        <dropZoneContext.Provider value={memoValue}>
          {children}
        </dropZoneContext.Provider>
      )}
    </>
  );
};
