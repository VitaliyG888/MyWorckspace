import { defaultViewports } from "../components/ViewportControls/default-viewports";
import { PrivateAppState } from "../types/Internal";

export const defaultAppState: PrivateAppState = {
  data: { content: [], root: {}, zones: {} },
  ui: {
    leftSideBarVisible: true,
    rightSideBarVisible: true,
    arrayState: {},
    itemSelector: null,
    componentList: {},
    isDragging: false,
    itemExpanded: {},
    previewMode: "edit",
    viewports: {
      current: {
        width: defaultViewports[0].width,
        height: defaultViewports[0].height || "auto",
      },
      options: [],
      controlsVisible: true,
    },
    expandedFieldGroups: {},
    field: { focus: null },
    plugin: { current: null },
  },
  indexes: {
    nodes: {},
    zones: {},
  },
};
