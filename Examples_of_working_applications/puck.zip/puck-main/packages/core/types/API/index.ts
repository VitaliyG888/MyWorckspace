import { ReactElement, ReactNode } from "react";
import { PuckAction } from "../../reducer";
import { WithDeepSlots } from "../Internal";
import { DefaultComponentProps } from "../Props";
import { AppState } from "./../AppState";
import { ComponentDataOptionalId, Content, Data } from "./../Data";
import { Overrides } from "./Overrides";
import { FieldTransforms } from "./FieldTransforms";
import { Config, DefaultComponents } from "../Config";

export type Permissions = {
  drag: boolean;
  duplicate: boolean;
  delete: boolean;
  edit: boolean;
  insert: boolean;
} & Record<string, boolean>;

export type IframeConfig = {
  enabled?: boolean;
  waitForStyles?: boolean;
  syncHostStyles?: boolean;
};

export type DndBehavior = "auto" | "fluid" | "static";

export type DndConfig = {
  disableAutoScroll?: boolean;
  disableOutlineDrag?: boolean;
  enableDragHandle?: boolean;
  /**
   * - `auto` (default): fluid drags within a slot, switching to a static
   *   line placeholder when dragging between slots, inserting a new item,
   *   or dragging from the action bar drag handle
   * - `fluid`: always animate sibling items during a drag
   * - `static`: always show a line placeholder during a drag, only
   *   animating sibling items on drop
   */
  behavior?: DndBehavior;
};

export type OnAction<UserData extends Data = Data> = (
  action: PuckAction,
  appState: AppState<UserData>,
  prevAppState: AppState<UserData>
) => void;

export type Plugin<UserConfig extends Config = Config> = {
  name?: string;
  label?: string;
  icon?: ReactNode;
  render?: () => ReactElement;
  overrides?: Partial<Overrides<UserConfig>>;
  fieldTransforms?: FieldTransforms<UserConfig>;
  mobilePanelHeight?: "toggle" | "min-content";
};

export type History<D = any> = {
  state: D;
  id?: string;
};

type InitialHistoryAppend<AS = Partial<AppState>> = {
  histories: History<AS>[];
  index?: number;
  appendData?: true;
};

type InitialHistoryNoAppend<AS = Partial<AppState>> = {
  histories: [History<AS>, ...History<AS>[]]; // Array with minimum length of 1
  index?: number;
  appendData?: false;
};

export type InitialHistory<AS = Partial<AppState>> =
  | InitialHistoryAppend<AS>
  | InitialHistoryNoAppend<AS>;

export type Slot<
  Props extends { [key: string]: DefaultComponentProps } = {
    [key: string]: DefaultComponentProps;
  }
> = {
  [K in keyof Props]: ComponentDataOptionalId<
    Props[K],
    K extends string ? K : never
  >;
}[keyof Props][];

export type WithSlotProps<
  Target extends Record<string, any>,
  Components extends DefaultComponents = DefaultComponents,
  SlotType extends Content<Components> = Content<Components>
> = WithDeepSlots<Target, SlotType>;

export type RichText = string | ReactNode;

export * from "./DropZone";
export * from "./Viewports";

export type { Overrides };

export * from "./FieldTransforms";
