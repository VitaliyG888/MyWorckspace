export const registerFeatureFlags = () => {};
